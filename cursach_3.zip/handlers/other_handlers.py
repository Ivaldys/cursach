from aiogram import  Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from config_data.config import load_config
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import default_state, State, StatesGroup
from lexiconn.lexicon_ru import desc
router = Router()
config = load_config()

bot = Bot(token=config.tg_bot.token)



# Этот хэндлер будет срабатывать на любые ваши текстовые сообщения,
# кроме команд "/start" и "/help"

# Этот хэндлер будет срабатывать на команду "/help"
@router.message(Command(commands=['help']))
async def process_help_command(message: Message):
    await message.answer( 'Почта для помощи: Ivaldya@mail.ru')

@router.message(Command(commands=['contact']))
async def process_contact_command(message: Message):
    user_id = message.from_user.id
    await message.answer('Телеграмм: @Ivaldys\nНомер телефона: +7 (925)-286-31-42')


@router.message(Command(commands=['description']))
async def process_description_command(message: Message):
    user_id = message.from_user.id
    await message.answer(desc)

@router.message(Command(commands=['exit']))
async def process_exit_command(message: Message,  state: FSMContext):
    await state.set_state(default_state)