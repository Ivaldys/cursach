import sqlite3
import use_database.post_information
def teacher_name(tg_id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_name FROM teacher WHERE teacher_tg_id = {tg_id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def teachers_surname(tg_id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_surname FROM teacher WHERE teacher_tg_id = {tg_id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def teachers_course(tg_id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_course FROM teacher WHERE teacher_tg_id = {tg_id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def teachers_phone(tg_id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_phonenumber FROM teacher WHERE teacher_tg_id = {tg_id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def teachers_mail(tg_id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_mail FROM teacher WHERE teacher_tg_id = {tg_id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def teachers_university(tg_id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_university FROM teacher WHERE teacher_tg_id = {tg_id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def teachers_faculty(tg_id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_faculty FROM teacher WHERE teacher_tg_id = {tg_id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def teachers_money(tg_id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT money FROM teacher WHERE teacher_tg_id = {tg_id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def teachers_id(tg_id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_id FROM teacher WHERE teacher_tg_id = {tg_id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def teacher_tg_id(id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_tg_id FROM teacher WHERE teacher_id = {id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def teacher_usrname(id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_username FROM teacher WHERE teacher_tg_id = {id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def get_review_dict(user_id):
    tg_id = use_database.post_information.get_teacher_page_review(user_id)
    teacher =  use_database.post_information.get_id_fromtg(tg_id, "teacher")
    page = use_database.post_information.get_page_review(user_id)
    new = (page-1) * 10
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT review, grade FROM deal WHERE teacher_id = {teacher} LIMIT 10 OFFSET {new}")
    result = cursor.fetchall()
    connection.commit()
    connection.close()
    return result

def get_review_desc(user_id,chast, grade):
    th_id = use_database.post_information.get_teacher_page_review(user_id)
    teacher_id = teachers_id(th_id)
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT review FROM deal WHERE teacher_id = {teacher_id} AND grade = {grade}")
    result = cursor.fetchall()[0]
    connection.commit()
    connection.close()
    for i in result:
        if (chast in i):
            return i

def get_review_date(user_id, desc, grade):
    th_id = use_database.post_information.get_teacher_page_review(user_id)
    teacher_id = teachers_id(th_id)
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT date FROM deal WHERE teacher_id = {teacher_id} AND grade = {grade} AND review = '{desc}'")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def get_review_teacher(post):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT teacher_id FROM deal WHERE post_id = {post}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result

def set_review_desc(post,th_id, text):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"UPDATE deal SET review = '{text}' WHERE post_id = {post} AND teacher_id = {th_id}")
    connection.commit()
    connection.close()

def set_revies_grade(post,th_id, text):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"UPDATE deal SET grade = {text} WHERE post_id = {post} AND teacher_id = {th_id}")
    connection.commit()
    connection.close()

def set_otkl(id,post):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"UPDATE deal SET teacher_id = {id} WHERE post_id = {post}")
    connection.commit()
    connection.close()

def del_otkl(post):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"UPDATE deal SET teacher_id = {0} WHERE post_id = {post}")
    connection.commit()
    connection.close()

def get_otzyvy(user_id):
    page = use_database.post_information.get_page_review(user_id)
    teacher =  use_database.post_information.get_id_fromtg(user_id, "teacher")
    new = (page-1) * 10
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT review, grade FROM deal WHERE teacher_id = {teacher} LIMIT 10 OFFSET {new}")
    result = cursor.fetchall()
    connection.commit()
    connection.close()
    return result

def plus_otkl(number, id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT money FROM teacher WHERE teacher_tg_id = {id}")
    result = cursor.fetchone()[0]
    cursor.execute(f"UPDATE teacher SET money = {result + number} WHERE teacher_tg_id = {id}")
    connection.commit()
    connection.close()

def minus_otkl(id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT money FROM teacher WHERE teacher_tg_id = {id}")
    result = cursor.fetchone()[0]
    cursor.execute(f"UPDATE teacher SET money = {result - 1} WHERE teacher_tg_id = {id}")
    connection.commit()
    connection.close()

def get_otkl(id):
    connection = sqlite3.connect('my_database.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT money FROM teacher WHERE teacher_tg_id = {id}")
    result = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    return result